Numder Puzzle - Godot 3.6.1 project assembled by assistant.

Open this project in Godot 3.6.1. Autoloads are set in project.godot.
Replace or review assets in assets/ (icons, fonts, sounds).

To build APK, configure Android SDK/NDK/JDK in Editor Settings -> Export -> Android.
Create a release keystore and put it in android/release_key.jks for release builds.
